year = int(input('Укажи свой возраст: '))
if year > 18:
    print("Доступ разрешен")
else:
    print("Доступ запрещен")