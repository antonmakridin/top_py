passwd1 = input('Введите пароль: ')
passwd2 = input('Повторите пароль: ')
if passwd1 == passwd2:
    print('Регистрация успешна')
else:
    print('Введенные пароли не совпадают')