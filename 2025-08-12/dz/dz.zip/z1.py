class Chat:
    def __init__(self):
        pass

    def hello(self):
        print('Привет!')
    
    def how(self):
        print('Как дела?')
    
    def buy(self):
        print('Пока!')
        
chat = Chat()
chat.hello()
chat.how()
chat.buy()